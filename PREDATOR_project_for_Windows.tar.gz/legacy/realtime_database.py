import firebase_admin
from firebase_admin import credentials, db
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Callable
import json
import threading
import time

class RealtimeGameDatabase:
    def __init__(self):
        # Инициализация Firebase
        cred = credentials.Certificate({
            "type": "service_account",
            "project_id": "game-d11c5",
            "private_key_id": "60ea639d71f2c9032b22d0c1d6dd369bee7c449a",
            "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDyPSqlCerdiotR\nafm+h7/3GxRiyhxMgCVI0d+llCFvLxyxXs7/5+AkfqU3yvJgpLQWlK1oC3tBYuLN\n1IJBQ21gRG3uwldx3p3kV3PnAQD0dNCFeZ6uvz66JfrdzT/D/sR7QEwDZVFxqARh\nUBbKAzosli0iTRGohuJ330DjcGdkIgBmjXTznP10OdVdG33sEZZzJdh3UOElqrsE\n4Fzqelo1C5uO4u+wZKuwaIjXJYhKyGC6u+Xg79gwcnJ2Q4W2lOk1UB9zDkohEA6e\nX3waGkpK9692b++YQROsQ6IxlJU4+oHJoIpEHXn9cRfLMO4DI4BJ4y3uP5Hv8UXu\nLsgPi5vnAgMBAAECggEAYFUn1Ns1TiYPEnDpEzasBip8OG80ws2BRkzEOnZGt48O\nQ5E3E7jUP98neCEas4k8XvCAZ2yNdyrKlF1K8YZNhGeiKj2aBdwogUqv+nFBPnYI\nCNSdYNQIL4H0GmnJznlODM+8iusrcN4G4+Y0MeEHrPyJ9Wadu53siQw9I1WroDtJ\nQ6MlMtFbwGWLZBYZXRJe52bjcSzGMcs067LHB4KObjyzJzPMBecBrq0Hke0em3RR\n2hhbkEZBfg1/vtZjFMB8L9gDqmRyXzG7U+tLNjDAlcc+8d8lSPgH9di5iKm6JK0Q\nF8u29LS9wvlJrx2QDT2yGnvF5xM5pKhJWnxqjiqFTQKBgQD88UVlsyEsm0E/XxfM\nuqhBYuTcCTyzsGlcgUC8MogktqwEu+Jao8A23InL8kQVlRCjcEnSKhdW6ZRFD0FG\n8f2eCvwG0PRQP4MhnEaKdZEdV92RvPLnIAN/v6HP6rq0uMsSoNTgfrdzS2CSQQSH\n606JaxwX9zmJUPOu/GOh5q4m3QKBgQD1KsYCv4chdWlo4sbQAnKUl8/Xe1yXM7Id\neaHPo1Po0idK1odwSBpV+mbdtiwv/pE8qRk1/l2Md3ICMxSiP9BqzjDqrKjba4MR\nlLjklXQkj5TpEdYct717ldVaA/yJppglEHyVliez01kFMIVKibKA49FfAcDhfn5P\nHA1pWZRHkwKBgQCCYQcJbfT6nihatvR4lfomggg/lw9P++3DPeiVWWKtse8nHYWG\nfQOWA8WPd5g6m7SQ2k9i4klXhlzj4AIgxJma/kR8avaT6rj3+SqvMfyT6HeQKJn4\nIptLHQcWOgL1Jo+eUYKJGSgMaN0lZhgky1iXIru/arKgojaJixT8HgDEjQKBgQCR\nMBqBaCFDbD/XcG0ipEBsxRa92n1zwZaao/xydZvshf/k7vTYRqrp/ddLN2YlqhEi\nplWaxx9pXxcyPEPc7gOkLKWFZGi/QIUnNTblj6hvOmSKPhjZeuqItKvbmf7FGdaC\nJKhTAdBTSzctvpVBFhiTAdds9yHdqEZu3QMIP5dzZwKBgQDOC2c9oIYBqP6ve0rm\nFwDKJKoesuesV7HtmKLtNQ7HaVqvZE5Z1d03kosMSOvA/JK7QWe9J22cAS6anjtZ\nnz+33Cfvqv+Pg7UIub+q6N6WbZL3ZGoxbphE0boDnz+kf8a2k0AjRmVfZ5+KSkgW\nR9Nyx9Qb3AM+vAfKMDi92aUXyQ==\n-----END PRIVATE KEY-----\n",
            "client_email": "firebase-adminsdk-fbsvc@game-d11c5.iam.gserviceaccount.com",
            "client_id": "112816931830867344938",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40game-d11c5.iam.gserviceaccount.com",
            "universe_domain": "googleapis.com"
        })
        
        firebase_admin.initialize_app(cred, {
            'databaseURL': 'https://game-d11c5-default-rtdb.firebaseio.com/'
        })
        
        self.ref = db.reference('/')
        self.listeners = {}
        
    def register_player(self, username: str, password: str) -> bool:
        """Регистрация нового игрока"""
        try:
            players_ref = self.ref.child('players')
            all_players = players_ref.get()
            
            if all_players:
                for player_id, player_data in all_players.items():
                    if player_data.get('username') == username:
                        return False
            
            new_player = {
                'username': username,
                'password': password,
                'created_at': datetime.now().isoformat(),
                'last_online': datetime.now().isoformat(),
                'is_online': False,
                'total_score': 0,
                'games_played': 0
            }
            
            players_ref.push(new_player)
            return True
            
        except Exception as e:
            print(f"Ошибка регистрации: {e}")
            return False
    
    def login_player(self, username: str, password: str) -> Optional[str]:
        """Авторизация игрока"""
        try:
            players_ref = self.ref.child('players')
            players = players_ref.get()
            
            if players:
                for player_id, player_data in players.items():
                    if player_data.get('username') == username and player_data.get('password') == password:
                        # Обновляем статус онлайн с таймстемпом
                        players_ref.child(player_id).update({
                            'is_online': True,
                            'last_online': datetime.now().timestamp(),
                            'last_ping': datetime.now().timestamp()
                        })
                        return player_id
            
            return None
            
        except Exception as e:
            print(f"Ошибка входа: {e}")
            return None
    
    def logout_player(self, player_id):
        """Выход игрока"""
        try:
            player_id_str = str(player_id)
            self.ref.child('players').child(player_id_str).update({
                'is_online': False,
                'last_online': datetime.now().timestamp()
            })
        except Exception as e:
            print(f"Ошибка выхода: {e}")
    
    def get_online_players(self, exclude_player_id=None) -> List[Dict]:
        """Получение списка АКТИВНЫХ онлайн игроков"""
        try:
            players_ref = self.ref.child('players')
            players = players_ref.get()
            
            online_players = []
            current_time = datetime.now().timestamp()
            
            if players:
                for player_id, player_data in players.items():
                    # Проверяем действительно ли игрок онлайн (был ping последние 30 секунд)
                    last_ping = player_data.get('last_ping', 0)
                    is_online = player_data.get('is_online', False)
                    
                    if is_online and (current_time - last_ping) < 30:
                        if exclude_player_id and str(player_id) == str(exclude_player_id):
                            continue
                            
                        online_players.append({
                            'id': str(player_id),
                            'username': player_data.get('username'),
                            'total_score': player_data.get('total_score', 0),
                            'games_played': player_data.get('games_played', 0)
                        })
            
            return online_players
            
        except Exception as e:
            print(f"Ошибка получения онлайн игроков: {e}")
            return []
    
    def create_game(self, player1_id: str, player2_id: str) -> str:
        """Создание новой игры"""
        try:
            games_ref = self.ref.child('games')
            
            new_game = {
                'player1_id': player1_id,
                'player2_id': player2_id,
                'created_at': datetime.now().isoformat(),
                'status': 'active',
                'current_round': 1,
                'current_question': 1,
                'player1_ready': False,
                'player2_ready': False
            }
            
            result = games_ref.push(new_game)
            return result.key
            
        except Exception as e:
            print(f"Ошибка создания игры: {e}")
            return None
    
    def create_round(self, game_id: str, round_number: int) -> str:
        """Создание нового раунда"""
        try:
            rounds_ref = self.ref.child('rounds')
            
            new_round = {
                'game_id': game_id,
                'round_number': round_number,
                'player1_choice': None,
                'player2_choice': None,
                'player1_score': 0,
                'player2_score': 0,
                'completed_at': None
            }
            
            result = rounds_ref.push(new_round)
            return result.key
            
        except Exception as e:
            print(f"Ошибка создания раунда: {e}")
            return None
    
    def save_question_choice(self, round_id: str, question_number: int, 
                          player_id: str, choice: str):
        """Сохранение выбора игрока в вопросе"""
        try:
            # Убедимся что round_id это строка
            round_id_str = str(round_id)
            
            round_data = self.ref.child('rounds').child(round_id_str).get()
            if not round_data:
                return
            
            game_id = round_data.get('game_id')
            game_data = self.ref.child('games').child(game_id).get()
            
            if not game_data:
                return
            
            player1_id = game_data.get('player1_id')
            player2_id = game_data.get('player2_id')
            
            # Определяем, какой игрок
            if player_id == player1_id:
                field = 'player1_choice'
            elif player_id == player2_id:
                field = 'player2_choice'
            else:
                return
            
            # Сохраняем выбор
            questions_ref = self.ref.child('round_questions')
            all_questions = questions_ref.get()
            
            question_key = None
            if all_questions:
                for q_key, q_data in all_questions.items():
                    if (q_data.get('round_id') == round_id_str and 
                        q_data.get('question_number') == question_number):
                        question_key = q_key
                        break
            
            if question_key:
                questions_ref.child(question_key).update({field: choice})
            else:
                new_question = {
                    'round_id': round_id_str,
                    'question_number': question_number,
                    field: choice
                }
                questions_ref.push(new_question)
                
        except Exception as e:
            print(f"Ошибка сохранения выбора: {e}")
    
    def get_player_stats(self, player_id) -> Dict:
        """Получение статистики игрока"""
        try:
            player_id_str = str(player_id)
            player_data = self.ref.child('players').child(player_id_str).get()
            
            if player_data:
                return {
                    'username': player_data.get('username'),
                    'total_score': player_data.get('total_score', 0),
                    'games_played': player_data.get('games_played', 0)
                }
            else:
                return {}
                
        except Exception as e:
            print(f"Ошибка получения статистики: {e}")
            return {}
    
    def ping_player(self, player_id):
        """Обновление ping для поддержания онлайн статуса"""
        try:
            player_id_str = str(player_id)
            self.ref.child('players').child(player_id_str).update({
                'last_ping': datetime.now().timestamp()
            })
        except Exception as e:
            print(f"Ошибка ping: {e}")
    
    def listen_to_game(self, game_id: str, callback: Callable):
        """Слушать изменения в игре"""
        def listener(event):
            callback(event.data)
        
        game_ref = self.ref.child('games').child(game_id)
        self.listeners[f'game_{game_id}'] = game_ref.listen(listener)
    
    def listen_to_round(self, round_id: str, callback: Callable):
        """Слушать изменения в раунде"""
        def listener(event):
            callback(event.data)
        
        round_ref = self.ref.child('rounds').child(round_id)
        self.listeners[f'round_{round_id}'] = round_ref.listen(listener)
    
    def listen_to_questions(self, round_id: str, callback: Callable):
        """Слушать изменения в вопросах раунда"""
        def listener(event):
            callback(event.data)
        
        # Используем правильный метод для Firebase Admin SDK
        questions_ref = self.ref.child('round_questions')
        query = questions_ref.order_by_child('round_id').equal_to(round_id)
        
        # Создаем listener для query
        self.listeners[f'questions_{round_id}'] = query.listen(listener)
    
    def update_game_status(self, game_id: str, player_id: str, ready: bool):
        """Обновить статус готовности игрока"""
        try:
            game_data = self.ref.child('games').child(game_id).get()
            if not game_data:
                return
            
            if player_id == game_data.get('player1_id'):
                self.ref.child('games').child(game_id).update({'player1_ready': ready})
            elif player_id == game_data.get('player2_id'):
                self.ref.child('games').child(game_id).update({'player2_ready': ready})
                
        except Exception as e:
            print(f"Ошибка обновления статуса игры: {e}")
    
    def get_question_choices(self, round_id: str, question_number: int) -> Dict:
        """Получить выборы обоих игроков для вопроса"""
        try:
            round_id_str = str(round_id)
            questions_ref = self.ref.child('round_questions')
            all_questions = questions_ref.get()
            
            choices = {'player1_choice': None, 'player2_choice': None}
            
            if all_questions:
                for q_data in all_questions.values():
                    if (q_data.get('round_id') == round_id_str and 
                        q_data.get('question_number') == question_number):
                        
                        if 'player1_choice' in q_data:
                            choices['player1_choice'] = q_data['player1_choice']
                        if 'player2_choice' in q_data:
                            choices['player2_choice'] = q_data['player2_choice']
                        break
            
            return choices
            
        except Exception as e:
            print(f"Ошибка получения выборов: {e}")
            return {'player1_choice': None, 'player2_choice': None}

# Для совместимости
class GameDatabase(RealtimeGameDatabase):
    pass
