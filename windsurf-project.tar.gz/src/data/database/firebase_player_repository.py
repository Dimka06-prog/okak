"""
Firebase реализация репозитория игроков
"""
import json
import time
import logging
import bcrypt
import firebase_admin
from typing import List, Optional
from firebase_admin import credentials, db
from datetime import datetime
from ..repositories.player_repository import PlayerRepository
from ..models.player import Player

logger = logging.getLogger(__name__)

class FirebasePlayerRepository(PlayerRepository):
    """Firebase реализация репозитория игроков"""
    
    def __init__(self, config_path: str = "src/config/firebase_config.json"):
        self.config_path = config_path
        self.ref = None
        self._connected = False
        self._load_config()
        self._init_firebase()
    
    def _load_config(self):
        """Загрузка конфигурации Firebase"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            logger.info("Конфигурация Firebase успешно загружена")
        except FileNotFoundError:
            logger.error(f"Файл конфигурации {self.config_path} не найден")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Ошибка парсинга JSON: {e}")
            raise
    
    def _init_firebase(self):
        """Инициализация Firebase"""
        try:
            if not firebase_admin._apps:
                cred = credentials.Certificate(self.config)
                firebase_admin.initialize_app(cred, {
                    'databaseURL': self.config['database_url']
                })
            self.ref = db.reference('/')
            self._connected = True
            logger.info("Firebase успешно инициализирован")
        except Exception as e:
            logger.error(f"Ошибка инициализации Firebase: {e}")
            self._connected = False
    
    def _ensure_connection(self):
        """Проверка и восстановление соединения"""
        try:
            if not self._connected:
                self._init_firebase()
            
            # Простая проверка соединения
            self.ref.child('connection_test').get()
            return True
        except Exception as e:
            logger.warning(f"Потеря соединения: {e}")
            try:
                self._init_firebase()
                return True
            except Exception as e:
                logger.error(f"Не удалось восстановить соединение: {e}")
                return False
    
    def _safe_operation(self, operation, *args, **kwargs):
        """Безопасное выполнение операции с попыткой восстановления"""
        max_retries = 3
        last_exception = None
        
        for attempt in range(max_retries):
            try:
                if self._ensure_connection():
                    return operation(*args, **kwargs)
                else:
                    logger.warning(f"Попытка {attempt + 1} не удалась - нет соединения")
                    time.sleep(1)
            except Exception as e:
                last_exception = e
                logger.error(f"Попытка {attempt + 1} провалилась: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
        
        if last_exception:
            raise last_exception
        return None
    
    def connect(self) -> bool:
        """Установить соединение"""
        return self._ensure_connection()
    
    def disconnect(self):
        """Закрыть соединение"""
        self._connected = False
        logger.info("Соединение с Firebase закрыто")
    
    def is_connected(self) -> bool:
        """Проверить статус соединения"""
        return self._connected
    
    def create_player(self, username: str, hashed_password: str) -> Optional[str]:
        """Создать нового игрока"""
        def _create():
            players_ref = self.ref.child('players')
            all_players = players_ref.get()
            
            # Проверка уникальности имени
            if all_players:
                for player_data in all_players.values():
                    if player_data.get('username') == username:
                        return None
            
            # Создание нового игрока
            new_player = {
                'username': username,
                'password': hashed_password,
                'created_at': datetime.now().isoformat(),
                'last_online': datetime.now().isoformat(),
                'is_online': False,
                'total_score': 0,
                'games_played': 0
            }
            
            result = players_ref.push(new_player)
            return result.key
        
        try:
            return self._safe_operation(_create)
        except Exception as e:
            logger.error(f"Ошибка создания игрока: {e}")
            return None
    
    def get_player_by_username(self, username: str) -> Optional[Player]:
        """Получить игрока по имени пользователя"""
        def _get():
            players_ref = self.ref.child('players')
            players = players_ref.get()
            
            if players:
                for player_id, player_data in players.items():
                    if player_data.get('username') == username:
                        return Player.from_dict({
                            'id': player_id,
                            **player_data
                        })
            return None
        
        try:
            return self._safe_operation(_get)
        except Exception as e:
            logger.error(f"Ошибка получения игрока по username: {e}")
            return None
    
    def get_player_by_id(self, player_id: str) -> Optional[Player]:
        """Получить игрока по ID"""
        def _get():
            player_data = self.ref.child('players').child(player_id).get()
            if player_data:
                return Player.from_dict({
                    'id': player_id,
                    **player_data
                })
            return None
        
        try:
            return self._safe_operation(_get)
        except Exception as e:
            logger.error(f"Ошибка получения игрока по ID: {e}")
            return None
    
    def update_player(self, player: Player) -> bool:
        """Обновить данные игрока"""
        def _update():
            self.ref.child('players').child(player.id).update(player.to_dict())
            return True
        
        try:
            return self._safe_operation(_update) or False
        except Exception as e:
            logger.error(f"Ошибка обновления игрока: {e}")
            return False
    
    def delete_player(self, player_id: str) -> bool:
        """Удалить игрока"""
        def _delete():
            self.ref.child('players').child(player_id).delete()
            return True
        
        try:
            return self._safe_operation(_delete) or False
        except Exception as e:
            logger.error(f"Ошибка удаления игрока: {e}")
            return False
    
    def get_online_players(self, exclude_player_id: Optional[str] = None) -> List[Player]:
        """Получить список онлайн игроков"""
        def _get_online():
            players_ref = self.ref.child('players')
            players = players_ref.get()
            
            online_players = []
            current_time = datetime.now().timestamp()
            
            if players:
                for player_id, player_data in players.items():
                    # Проверка активности (ping за последние 30 секунд)
                    last_ping = player_data.get('last_ping', 0)
                    is_online = player_data.get('is_online', False)
                    
                    if is_online and (current_time - last_ping) < 30:
                        if exclude_player_id and str(player_id) == str(exclude_player_id):
                            continue
                        
                        online_players.append(Player.from_dict({
                            'id': player_id,
                            **player_data
                        }))
            
            return online_players
        
        try:
            return self._safe_operation(_get_online) or []
        except Exception as e:
            logger.error(f"Ошибка получения онлайн игроков: {e}")
            return []
    
    def verify_password(self, username: str, password: str) -> Optional[str]:
        """Проверить пароль и вернуть ID игрока"""
        def _verify():
            players_ref = self.ref.child('players')
            players = players_ref.get()
            
            if players:
                for player_id, player_data in players.items():
                    if player_data.get('username') == username:
                        try:
                            if bcrypt.checkpw(password.encode('utf-8'), 
                                            player_data.get('password').encode('utf-8')):
                                return player_id
                        except Exception as e:
                            logger.error(f"Ошибка проверки пароля: {e}")
                            return None
            return None
        
        try:
            return self._safe_operation(_verify)
        except Exception as e:
            logger.error(f"Ошибка проверки пароля: {e}")
            return None
    
    def update_online_status(self, player_id: str, is_online: bool) -> bool:
        """Обновить онлайн статус игрока"""
        def _update_status():
            self.ref.child('players').child(player_id).update({
                'is_online': is_online,
                'last_online': datetime.now().isoformat(),
                'last_ping': datetime.now().timestamp()
            })
            return True
        
        try:
            return self._safe_operation(_update_status) or False
        except Exception as e:
            logger.error(f"Ошибка обновления онлайн статуса: {e}")
            return False
    
    def update_ping(self, player_id: str) -> bool:
        """Обновить ping для поддержания онлайн статуса"""
        def _ping():
            self.ref.child('players').child(player_id).update({
                'last_ping': datetime.now().timestamp()
            })
            return True
        
        try:
            return self._safe_operation(_ping) or False
        except Exception as e:
            logger.error(f"Ошибка обновления ping: {e}")
            return False
