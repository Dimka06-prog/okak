"""
Сервис матчмейкинга для соединения игроков в реальном времени
"""
import asyncio
import random
import time
from typing import Optional, Dict, List, Tuple, Any
from enum import Enum
import logging

logger = logging.getLogger(__name__)

class GameStatus(Enum):
    WAITING = "waiting"
    PLAYING = "playing"
    FINISHED = "finished"

class PlayerStatus(Enum):
    SEARCHING = "searching"
    MATCHED = "matched"
    PLAYING = "playing"
    DISCONNECTED = "disconnected"

class MatchmakingService:
    """Сервис для соединения игроков в реальном времени"""
    
    def __init__(self, database):
        self.database = database
        self.waiting_players = {}  # player_id -> timestamp
        self.active_games = {}     # game_id -> game_info
        self.player_games = {}     # player_id -> game_id
        
    async def start_matchmaking(self, player_id: str, player_name: str) -> Optional[str]:
        """Начать поиск игры для игрока"""
        try:
            # Если игрок уже в игре, возвращаем ID игры
            if player_id in self.player_games:
                return self.player_games[player_id]
            
            # Удаляем игрока из списка ожидания если он там был
            if player_id in self.waiting_players:
                del self.waiting_players[player_id]
            
            # Обновляем статус игрока на "в поиске"
            await self.database.update_player_status(player_id, "searching")
            
            # Ищем другого игрока в ожидании
            opponent_id = self._find_opponent(player_id)
            
            if opponent_id:
                # Нашли противника - создаем игру
                game_id = await self._create_game(player_id, player_name, opponent_id)
                return game_id
            else:
                # Противника нет - добавляем в очередь ожидания
                self.waiting_players[player_id] = time.time()
                await self.database.set_player_matchmaking(player_id, True)
                logger.info(f"Player {player_name} added to waiting queue")
                return None
                
        except Exception as e:
            logger.error(f"Error in matchmaking for {player_id}: {e}")
            return None
    
    def _find_opponent(self, player_id: str) -> Optional[str]:
        """Найти противника из списка ожидания"""
        # Удаляем себя из списка
        available_players = [pid for pid in self.waiting_players.keys() if pid != player_id]
        
        if not available_players:
            return None
        
        # Выбираем случайного противника
        opponent_id = random.choice(available_players)
        
        # Удаляем противника из очереди
        del self.waiting_players[opponent_id]
        
        return opponent_id
    
    async def _create_game(self, player1_id: str, player1_name: str, player2_id: str) -> str:
        """Создать новую игру между двумя игроками"""
        try:
            # Получаем имя второго игрока
            player2_info = await self.database.get_player(player2_id)
            player2_name = player2_info.get('username', 'Unknown') if player2_info else 'Unknown'
            
            # Создаем игру в базе данных
            game_id = await self.database.create_game(player1_id, player2_id)
            
            # Создаем структуру игры
            game_info = {
                'game_id': game_id,
                'player1': {
                    'id': player1_id,
                    'name': player1_name,
                    'status': PlayerStatus.MATCHED.value
                },
                'player2': {
                    'id': player2_id,
                    'name': player2_name,
                    'status': PlayerStatus.MATCHED.value
                },
                'status': GameStatus.PLAYING.value,
                'current_round': 1,
                'current_question': 1,
                'rounds': {
                    1: {'total_questions': 10, 'completed': False},
                    2: {'total_questions': 10, 'completed': False},
                    3: {'total_questions': 13, 'completed': False}
                },
                'created_at': time.time()
            }
            
            # Сохраняем в локальном состоянии
            self.active_games[game_id] = game_info
            self.player_games[player1_id] = game_id
            self.player_games[player2_id] = game_id
            
            # Обновляем статусы игроков
            await self.database.update_player_status(player1_id, "playing")
            await self.database.update_player_status(player2_id, "playing")
            await self.database.set_player_matchmaking(player1_id, False)
            await self.database.set_player_matchmaking(player2_id, False)
            
            # Создаем раунды в базе данных
            await self._create_game_rounds(game_id)
            
            logger.info(f"Game {game_id} created between {player1_name} and {player2_name}")
            return game_id
            
        except Exception as e:
            logger.error(f"Error creating game: {e}")
            return None
    
    async def _create_game_rounds(self, game_id: str):
        """Создать раунды игры в базе данных"""
        try:
            # Раунд 1 - 10 вопросов
            await self.database.create_round(game_id, 1, 10)
            # Раунд 2 - 10 вопросов  
            await self.database.create_round(game_id, 2, 10)
            # Раунд 3 - 13 вопросов
            await self.database.create_round(game_id, 3, 13)
            
        except Exception as e:
            logger.error(f"Error creating game rounds: {e}")
    
    async def cancel_matchmaking(self, player_id: str):
        """Отменить поиск игры"""
        try:
            if player_id in self.waiting_players:
                del self.waiting_players[player_id]
                await self.database.set_player_matchmaking(player_id, False)
                await self.database.update_player_status(player_id, "online")
                logger.info(f"Player {player_id} cancelled matchmaking")
                
        except Exception as e:
            logger.error(f"Error cancelling matchmaking for {player_id}: {e}")
    
    async def leave_game(self, player_id: str):
        """Покинуть игру"""
        try:
            if player_id in self.player_games:
                game_id = self.player_games[player_id]
                
                if game_id in self.active_games:
                    game_info = self.active_games[game_id]
                    
                    # Определяем какой игрок вышел
                    if game_info['player1']['id'] == player_id:
                        game_info['player1']['status'] = PlayerStatus.DISCONNECTED.value
                        opponent_id = game_info['player2']['id']
                    else:
                        game_info['player2']['status'] = PlayerStatus.DISCONNECTED.value
                        opponent_id = game_info['player1']['id']
                    
                    # Обновляем статус игры
                    game_info['status'] = GameStatus.FINISHED.value
                    
                    # Обновляем статус противника
                    await self.database.update_player_status(opponent_id, "online")
                    
                # Удаляем связи
                del self.player_games[player_id]
                await self.database.update_player_status(player_id, "online")
                
                logger.info(f"Player {player_id} left game {game_id}")
                
        except Exception as e:
            logger.error(f"Error leaving game for {player_id}: {e}")
    
    def get_game_info(self, game_id: str) -> Optional[Dict]:
        """Получить информацию об игре"""
        return self.active_games.get(game_id)
    
    def get_player_game(self, player_id: str) -> Optional[str]:
        """Получить ID игры игрока"""
        return self.player_games.get(player_id)
    
    async def cleanup_old_waiting_players(self, timeout_seconds: int = 300):
        """Очистка старых игроков в очереди (5 минут)"""
        try:
            current_time = time.time()
            expired_players = []
            
            for player_id, wait_time in self.waiting_players.items():
                if current_time - wait_time > timeout_seconds:
                    expired_players.append(player_id)
            
            for player_id in expired_players:
                await self.cancel_matchmaking(player_id)
                
        except Exception as e:
            logger.error(f"Error cleaning up old waiting players: {e}")
